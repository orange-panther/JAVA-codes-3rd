package analyzer;

public record LotteryTip(String id, int[] numbers) {
}
