package org.example.contactmanager.model;

public enum ContactType {
    BUSINESS,
    PRIVATE,
    NONE
}


