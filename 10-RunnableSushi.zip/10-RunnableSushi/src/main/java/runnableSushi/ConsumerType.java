package runnableSushi;

public enum ConsumerType {
    GUEST,
    CLEANER
}
